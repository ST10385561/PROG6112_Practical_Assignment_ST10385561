/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package studentmanagementapp;

import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Wavhu Budeli
 */
import javax.swing.JOptionPane;
import java.util.ArrayList;
public class StudentManagementApp {
    public static ArrayList<Student> studentList = new ArrayList<>();

    public static void main(String[] args) {
        displayMenu();
    }

    private static void displayMenu() {
        while (true) {
            String menu = "STUDENT MANAGEMENT APPLICATION\n" +
                    "*********************************\n" +
                    "1. Capture a new student\n" +
                    "2. Search for a student\n" +
                    "3. Delete a student\n" +
                    "4. Print student report\n" +
                    "5. Exit application";

            String choice = JOptionPane.showInputDialog(null, menu, "Menu", JOptionPane.PLAIN_MESSAGE);

            if (choice == null || choice.equals("5")) {
                JOptionPane.showMessageDialog(null, "Thank you for using the Student Management Application!");
                break;
            }

            switch (choice) {
                case "1":
                    captureNewStudent();
                    break;
                case "2":
                     int searchId = Integer.parseInt(JOptionPane.showInputDialog("Enter student ID to search:"));
                    searchStudent(searchId);
                    break;
                case "3":
                    deleteStudent();
                    break;
                case "4":
                    printStudentReport();
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Invalid choice. Please select a valid option.");
            }
        }
    }

    private static void captureNewStudent() {
        int id = Integer.parseInt(JOptionPane.showInputDialog("Enter student ID:"));
        String name = JOptionPane.showInputDialog("Enter student name:");
        int age;
        while (true) {
            try {
                age = Integer.parseInt(JOptionPane.showInputDialog("Enter student age:"));
                if (age >= 16) {
                    break;
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid age. Age must be 16 or older.");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid age (numeric).");
            }
        }
        String email = JOptionPane.showInputDialog("Enter student email:");
        String course = JOptionPane.showInputDialog("Enter student course:");

        Student newStudent = new Student(id, name, age, email, course);
        studentList.add(newStudent);

        JOptionPane.showMessageDialog(null, "Student details successfully saved!");
    }

    public static boolean searchStudent(int searchId ) {
        ///int searchId = Integer.parseInt(JOptionPane.showInputDialog("Enter student ID to search:"));
        boolean found = false;

        for (Student student : studentList) {
            if (student.getId() == searchId) {
                JOptionPane.showMessageDialog(null, "Student found:\n" +
                        "ID: " + student.getId() + "\n" +
                        "Name: " + student.getName() + "\n" +
                        "Age: " + student.getAge() + "\n" +
                        "Email: " + student.getEmail() + "\n" +
                        "Course: " + student.getCourse());
                found = true;
                break;
            }
        }

        if (!found) {
            JOptionPane.showMessageDialog(null, "Student not found.");
        }
        
        return found;
    }

    private static void deleteStudent() {
        int deleteId = Integer.parseInt(JOptionPane.showInputDialog("Enter student ID to delete:"));

        for (Student student : studentList) {
            if (student.getId() == deleteId) {
                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this student?");
                if (confirm == JOptionPane.YES_OPTION) {
                    studentList.remove(student);
                    JOptionPane.showMessageDialog(null, "Student deleted successfully.");
                }
                break;
            }
        }
    }

    public static String printStudentReport() {
        StringBuilder report = new StringBuilder("STUDENT REPORT:\n");
        for (Student student : studentList) {
            report.append("ID: ").append(student.getId()).append("\n")
                    .append("Name: ").append(student.getName()).append("\n")
                    .append("Age: ").append(student.getAge()).append("\n")
                    .append("Email: ").append(student.getEmail()).append("\n")
                    .append("Course: ").append(student.getCourse()).append("\n\n");
        }
        JOptionPane.showMessageDialog(null, report.toString());
        return report.toString();
    }
}

