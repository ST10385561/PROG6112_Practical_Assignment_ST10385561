/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package studentmanagementapp;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Wavhu Budeli
 */
public class StudentManagementAppTest {
    
    public StudentManagementAppTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class StudentManagementApp.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        StudentManagementApp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testcaptureNewStudent() {
        System.out.println("main");
        String[] args = null;
        StudentManagementApp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testsearchStudent() {
        System.out.println("Search student");
        assertFalse(StudentManagementApp.searchStudent(123));
        String[] args = null;
        StudentManagementApp.main(args);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testdeleteStudent() {
        System.out.println("delete");
        String[] args = null;
        StudentManagementApp.main(args);
         Student newStudent = new Student(123, "Wavhudi", 22, "Wavhudi@gmail.com", "Maths");
        StudentManagementApp.studentList.add(newStudent);
        assertEquals(1, StudentManagementApp.studentList.size());
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    @Test
    public void testprintStudentReport() {
        System.out.println("pring report");
        //String[] args = null;
        Student newStudent = new Student(123, "Wavhudi", 22, "Wavhudi@gmail.com", "Maths");
       
        String result = "STUDENT REPORT:\n"+"ID: 123\n"+"Name: Wavhudi\n"+"Age: 22\n"+"Email: Wavhudi@gmail.com\n"+"Course: Maths\n\n";
        
        StudentManagementApp.studentList.add(newStudent);
        assertEquals( result,StudentManagementApp.printStudentReport());
       
    }
}
