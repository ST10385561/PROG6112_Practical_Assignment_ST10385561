/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author Wavhu Budeli
 */
public class DicePair extends Dice {

    private int sum;

    public void rollPair() {
        roll(); // Roll the first die
        int die1Value = getValue();
        roll(); // Roll the second die
        int die2Value = getValue();
        sum = die1Value + die2Value;
    }

    public int getSum() {
        return sum;
    }
}
