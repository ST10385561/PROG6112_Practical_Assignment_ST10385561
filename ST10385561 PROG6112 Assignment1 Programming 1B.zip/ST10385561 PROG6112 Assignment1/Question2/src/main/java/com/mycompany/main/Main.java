/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.main;

/**
 *
 * @author Wavhu Budeli
 */
public class Main {
    public static void main(String[] args) {
        DicePair dicePair = new DicePair();
        dicePair.rollPair();

        int sum = dicePair.getSum();
        System.out.println("Dice 1: " + dicePair.getValue());
        System.out.println("Dice 2: " + dicePair.getValue());
        System.out.println("Sum: " + sum);

        if (sum == 7 || sum == 11) {
            System.out.println("You win!");
        } else if (sum == 2 || sum == 3 || sum == 12) {
            System.out.println("You lose!");
        } else {
            System.out.println("Keep rolling...");
            // Implement the logic for additional rolls for the code(this is off course optional)
        }
    }
}

