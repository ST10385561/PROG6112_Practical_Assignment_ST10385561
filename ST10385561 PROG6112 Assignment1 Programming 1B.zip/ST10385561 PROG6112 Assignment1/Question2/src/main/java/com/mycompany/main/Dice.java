/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.main;

/**
 *
 * @author Wavhu Budeli
 */

public class Dice {
    private int value;

    public Dice() {
        // Initialize the dice with a random value (1 to 6)
        roll();
    }

    public void roll() {
        // Simulate rolling of the dice
        value = (int) (Math.random() * 6) + 1;
    }

    public int getValue() {
        return value;
    }
}